<!-- jeg_search_hide with_result no_result -->
<div class="jeg_search_result jeg_search_hide with_result">
    <div class="search-result-wrapper">
    </div>
    <div class="search-link search-noresult">
        <?php jnews_print_translation('No Result', 'jnews', 'no_result'); ?>
    </div>
    <div class="search-link search-all-button">
        <i class="fa fa-search"></i> <?php jnews_print_translation('View All Result', 'jnews', 'view_all_result'); ?>
    </div>
</div>