<div class="post-ajax-overlay">
    <div class="preloader_type preloader_<?php echo esc_html(get_theme_mod('jnews_sidefeed_ajax_loader', 'dot')); ?>">
        <div class="newsfeed_preloader jeg_preloader dot">
            <span></span><span></span><span></span>
        </div>
        <div class="newsfeed_preloader jeg_preloader circle">
            <div class="jnews_preloader_circle_outer">
                <div class="jnews_preloader_circle_inner"></div>
            </div>
        </div>
        <div class="newsfeed_preloader jeg_preloader square">
            <div class="jeg_square"><div class="jeg_square_inner"></div></div>
        </div>
    </div>
</div>