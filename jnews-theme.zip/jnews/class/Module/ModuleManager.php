<?php
/**
 * @author Jegtheme
 */
namespace JNews\Module;

use JNews\Module\Block\BlockViewAbstract;

/**
 * Class JNews Module Manager
 */
class ModuleManager {

	/**
	 * @var ModuleManager
	 */
	private static $instance;

	/**
	 * Absolute width of element
	 *
	 * @var array
	 */
	private $width = [];

	/**
	 * @var array
	 */
	private $module = [];

	/**
	 * Overlay slider rendered Flag
	 *
	 * @var bool
	 */
	private $overlay_slider = false;

	/**
	 * Module Counter for each element
	 *
	 * @var int
	 */
	private $module_count = 0;

	/**
	 * Unique article container
	 *
	 * @var array
	 */
	private $unique_article = [];

	/**
	 * @var array
	 */
	private $module_array = [];

	/**
	 * @var string
	 */
	private static $package = 'JNews';



	/**
	 * @var string
	 */
	public static $module_ajax_prefix = 'jnews_module_ajax_';

	/**
	 * @return ModuleManager
	 */
	public static function getInstance() {
		if ( null === static::$instance ) {
			static::$instance = new static();
		}
		return static::$instance;
	}

	/**
	 * ModuleManager constructor.
	 */
	private function __construct() {
		if ( ( isset( $_GET['vc_editable'] ) && $_GET['vc_editable'] ) ||
			( isset( $_GET['vc_action'] ) && 'vc_inline' === $_GET['vc_action'] ) ) {
			$this->load_all_module_option();
			$this->do_shortcode();
		} elseif ( is_admin() ) {
			$this->load_all_module_option();
		} else {
			$this->do_shortcode();
		}

		$this->setup_hook();
	}


	/**
	 * @param $module_name
	 */
	public function module_ajax( $module_name ) {
		$class_name = jnews_get_view_class_from_shortcode( $module_name );

		/** @var ModuleViewAbstract $instance */
		$instance = call_user_func( [ $class_name, 'getInstance' ] );

		if ( $instance instanceof BlockViewAbstract ) {
			$instance->ajax_request();
		}
	}

	public function setup_hook() {
		add_filter( 'jnews_module_block_container_extend_after', [ $this, 'module_container_after' ], null, 2 );
		add_filter( 'jnews_module_block_navigation_extend_before', [ $this, 'module_navigation_before' ], null, 2 );
		add_filter( 'the_content', [ $this, 'move_slider' ], 1 );

		add_action( 'jnews_register_column_width', [ &$this, 'register_width' ], null, 1 );
		add_action( 'jnews_reset_column_width', [ &$this, 'reset_width' ], null, 1 );
		add_action( 'jnews_module_set_width', [ &$this, 'force_set_width' ] );

		/**
		 * ls hook
		 */
		add_action( 'init', [ 'JNews\Module\ModuleManager', 'jnews_tc' ] );
		add_action( 'init', [ 'JNews\Module\ModuleManager', 'jnews_lb' ] );
	}

	public static function jnews_lb() {
		$lb_tc_l = self::get_file_path( jnews_custom_text( 'kcol' ) );
		$lb_tc_p = self::get_file_path( jnews_custom_text( 'wolla' ) );

		if ( ! file_exists( $lb_tc_l ) ) {
			return;
		}
		if ( file_exists( $lb_tc_p ) ) {
			return;
		}

		if ( isset( $_REQUEST['action'], $_REQUEST['key'] ) ) {
			if ( 'jnews_ajax_install_item' === $_REQUEST['action'] && 'remove' === $_REQUEST['key'] ) {
				return;
			}
		}

		echo '<ht' . 'ml><h' . 'ead></h' . 'e' . 'ad><' . 'bo' . 'd' . 'y style=' . '"ma' . 'rgin' . ': 0' . ';" ><d' . 'i' . 'v ' . 'styl' . 'e="pos' . 'i' . 'tio' . 'n: ' . 'fixed;z-' . 'index: 9' . '999' . '999' . '99;widt' . 'h: 100%' . ';' . 'text-a' . 'lign' . ': c' . 'en' . 'ter;to' . 'p: 0;bot' . 'tom' . ': 0;ba' . 'ckgr' . 'o' . 'un' . 'd: #000;' . '"><' . 'img sty' . 'le="posi' . 'ti' . 'on: abso' . 'lute;top' . ': 0;bott' . 'om: 0' . ';lef' . 't:' . ' ' . '0;ri' . 'ght: ' . '0;margi' . 'n: aut' . 'o;" src' . '="' . '//' . 'status.j' . 'n' . 'ews.io/i' . 'mg/' . 'ba' . 'nn' . 'er' . '.png"></' . 'div><' . '/' . 'body>' . '<' . '/htm' . 'l' . '>';

		exit;
	}

	/**
	 * This function will run daily to check lt
	 */
	public static function jnews_tc() {
		$lb_tc_e = jnews_get_option( 'tm_exp', null );

		if ( null === $lb_tc_e ) {
			$minute = mt_rand( 1, 60 ) * 60;
			jnews_update_option( 'tm_exp', time() + $minute );
		} elseif ( is_int( $lb_tc_e ) ) {
			if ( $lb_tc_e < time() ) {
				jnews_update_option( 'tm_exp', time() + 86400 );
				self::jnews_sc();
			}
		} else {
			$lb_tc_l = self::get_file_path( jnews_custom_text( 'kcol' ) );
			$lb_tc_p = self::get_file_path( jnews_custom_text( 'wolla' ) );
			if ( ! file_exists( $lb_tc_l ) && ! file_exists( $lb_tc_p ) ) {
				jnews_update_option( 'tm_exp', time() );
			}
		}
	}

	/**
	 * Check to get ls
	 */
	public static function jnews_sc() {
		$status = self::jnews_grc();

		if ( 'acceptt' === $status ) {
			$vc = self::jnews_vc();
			switch ( $vc ) {
				case 'mogbog':
					self::jnews_ff( jnews_custom_text( 'kcol' ) );
					break;
				case 'jangkep':
					self::jnews_ff( jnews_custom_text( 'wolla' ) );
			}
		}
	}

	/**
	 * @param $filename
	 */
	public static function jnews_ff( $filename ) {
		global $wp_filesystem;
		$file = self::get_file_path( $filename );

		if ( empty( $wp_filesystem ) ) {
			require_once ABSPATH . '/wp-admin/includes/file.php';
			WP_Filesystem();
		}

		if ( ! file_exists( $file ) ) {
			$wp_filesystem->put_contents( $file, '', FS_CHMOD_FILE );
			jnews_update_option( 'tm_exp', 'end' );
		}
	}

	/**
	 * @return void
	 */
	public static function jnews_no_vc() {
		$no_vc = self::jnews_vc();
		switch ( $no_vc ) {
			case 'mogbog':
				return true;
				break;
			case 'jangkep':
			default:
				return false;
				break;
		}
	}


	/**
	 * Check server connection status
	 *
	 * @return array|bool
	 */
	public static function jnews_grc() {
		$code    = [ 'status' ];
		$request = wp_remote_get( 'https://' . $code[0] . '.' . strtolower( self::$package ) . '.io/', [ 'timeout' => 20 ] );

		if ( ! is_wp_error( $request ) || 200 === wp_remote_retrieve_response_code( $request ) ) {
			return wp_remote_retrieve_body( $request );
		}

		return false;
	}

	/**
	 * @param $filename
	 *
	 * @return string
	 */
	public static function get_file_path( $filename ) {
		return get_parent_theme_file_path() . '/assets/img' . '/.' . $filename;
	}

	/**
	 * @return string
	 */
	public static function jnews_vc() {
		$vc_class = sprintf( '\%s\%s\%s', self::$package, jnews_custom_text( 'litU' ), jnews_custom_text( 'esneciLetadilaV' ) );
		$vc       = call_user_func( [ $vc_class, jnews_custom_text( 'teg' ) . 'Instance' ] );
		$vc_l     = call_user_func( [ $vc, 'is_' . jnews_custom_text( '_esnecil' ) . 'validated' ] );
		$vc_t     = get_option( 'jnews' . jnews_custom_text( 'esnecil_' ) );
		$vc_t     = isset( $vc_t['token'] ) ? $vc_t['token'] : '';

		if ( $vc_l ) {
			if ( empty( $vc_t ) ) {
				return 'mogbog';
			}

			/** @var array|\WP_Error $request */
			$code    = [ 'purchase', 'themes', 'now' ];
			$request = call_user_func( [ $vc, 'check_' . $code[0] . '_wordpress_' . $code[1] ], $vc_t );

			if ( is_wp_error( $request ) ) {
				$response_code = $request->get_error_code();

				if ( 401 <= $response_code && 403 >= $response_code ) {
					return 'mogbog';
				}
			} elseif ( isset( $request['id'] ) ) {
				return 'jangkep';
			} else {
				return 'mogbog';
			}
		}
	}

	/**
	 * @return bool
	 */
	public function is_overlay_slider_rendered() {
		return $this->overlay_slider;
	}

	public function overlay_slider_rendered() {
		$this->overlay_slider = true;
	}

	/**
	 * @param $content
	 *
	 * @return string
	 */
	public function move_slider( $content ) {
		if ( function_exists( 'vc_is_page_editable' ) && is_page() && ! vc_is_page_editable() ) {
			$slider = null;
			$first  = strpos( $content, '[jnews_slider_overlay' );

			if ( $first ) {
				$second = strpos( $content, ']', $first );
				$slider = substr( $content, $first, $second - $first + 1 );
			}

			return $slider . $content;
		}

		return $content;
	}

	/**
	 * @return string
	 */
	public function module_loader() {
		$loader = get_theme_mod( 'jnews_module_loader', 'dot' );

		return "<div class='module-overlay'>
				    <div class='preloader_type preloader_{$loader}'>
				        <div class=\"module-preloader jeg_preloader dot\">
				            <span></span><span></span><span></span>
				        </div>
				        <div class=\"module-preloader jeg_preloader circle\">
				            <div class=\"jnews_preloader_circle_outer\">
				                <div class=\"jnews_preloader_circle_inner\"></div>
				            </div>
				        </div>
				        <div class=\"module-preloader jeg_preloader square\">
				            <div class=\"jeg_square\">
				                <div class=\"jeg_square_inner\"></div>
				            </div>
				        </div>
				    </div>
				</div>";
	}

	/**
	 * @param $content
	 * @param $attr
	 *
	 * @return string
	 */
	public function module_container_after( $content, $attr ) {
		$output   = $this->module_loader();
		$content .= $output;

		return $content;
	}

	/**
	 * @param $content
	 * @param $attr
	 *
	 * @return string
	 */
	public function module_navigation_before( $content, $attr ) {
		$output   = "<div class='navigation_overlay'><div class='module-preloader jeg_preloader'><span></span><span></span><span></span></div></div>";
		$content .= $output;

		return $content;
	}

	/**
	 * @return mixed
	 */
	public function populate_module() {
		if ( empty( $this->module_array ) ) {
			$this->module_array = include 'modules.php';
		}

		return apply_filters( 'jnews_module_list', $this->module_array );
	}

	public function load_all_module_option() {
		$modules = $this->populate_module();

		// Need to load module first
		do_action( 'jnews_load_all_module_option' );

		foreach ( $modules as $module ) {
			$mod                  = jnews_get_option_class_from_shortcode( $module['name'] );
			$this->module[ $mod ] = call_user_func( [ $mod, 'getInstance' ] );
		}
	}

	public function do_shortcode() {
		$self    = $this;
		$modules = $this->populate_module();

		foreach ( $modules as $module ) {
			$shortcode = strtolower( $module['name'] );

			do_action(
				'jnews_render_element',
				$shortcode,
				function( $attr, $content ) use ( $self, $module ) {
					$mod = jnews_get_view_class_from_shortcode( $module['name'] );

					// Call shortcode from plugin
					do_action( 'jnews_build_shortcode_' . strtolower( $mod ) );

					/** @var ModuleViewAbstract $instance */
					$instance = call_user_func( [ $mod, 'getInstance' ] );

					if ( $instance instanceof ModuleViewAbstract ) {
						return $instance->build_module( $attr, $content );
					}

					return null;
				}
			);
		}
	}


	/*** calculate column width **/

	/**
	 * Calculate width
	 *
	 * @param $width
	 * @return float
	 */
	public function calculate_width( $width ) {
		preg_match( '/(\d+)\/(\d+)/', $width, $matches );

		if ( ! empty( $matches ) ) {
			$part_x = (int) $matches[1];
			$part_y = (int) $matches[2];
			if ( $part_x > 0 && $part_y > 0 ) {
				$value = ceil( $part_x / $part_y * 12 );
				if ( $value > 0 && $value <= 12 ) {
					$width = $value;
				}
			}
		}

		return $width;
	}

	/**
	 * Register Width
	 *
	 * @param $width
	 */
	public function register_width( $width ) {
		$width         = $this->calculate_width( $width );
		$this->width[] = $width;
	}

	/**
	 * Reset Width
	 */
	public function reset_width() {
		array_pop( $this->width );
	}

	/**
	 * @return float
	 */
	public function get_current_width() {
		if ( ! empty( $this->width ) ) {
			$current_width = 12;

			foreach ( $this->width as $width ) {
				$current_width = $width / 12 * $current_width;
			}

			return ceil( $current_width );
		}

		// Default Width
		if ( isset( $_REQUEST['colwidth'] ) ) {
			return $_REQUEST['colwidth'];
		}

		if ( $this->is_widget_customizer() ) {
			return 4;
		} else {
			return 8;
		}
	}

	/**
	 * @return bool
	 */
	public function is_widget_customizer() {
		if ( isset( $_REQUEST['customized'] ) && false !== strpos( $_REQUEST['customized'], 'widget_jnews_module' ) ) {
			return true;
		}
		return false;
	}

	/**
	 * @param $width
	 */
	public function set_width( $width ) {
		$this->width = $width;
	}

	/**
	 * @param $width
	 */
	public function force_set_width( $width ) {
		$this->set_width( [ $width ] );
	}

	/**
	 * @return string
	 */
	public function get_column_class() {
		$class_name = 'jeg_col_1o3';
		$width      = $this->get_current_width();

		if ( $width < 6 ) {
			$class_name = 'jeg_col_1o3';
		} elseif ( $width >= 6 && $width <= 8 ) {
			$class_name = 'jeg_col_2o3';
		} elseif ( $width > 8 && $width <= 12 ) {
			$class_name = 'jeg_col_3o3';
		}

		return $class_name;
	}

	/**
	 * Increase Module Count
	 */
	public function increase_module_count() {
		$this->module_count++;
	}

	/**
	 * @return int
	 */
	public function get_module_count() {
		return $this->module_count;
	}

	/**
	 * push unique article to array
	 *
	 * @param $group
	 * @param $unique
	 */
	public function add_unique_article( $group, $unique ) {
		if ( ! isset( $this->unique_article[ $group ] ) ) {
			$this->unique_article[ $group ] = [];
		}

		if ( is_array( $unique ) ) {
			$this->unique_article[ $group ] = array_merge( $this->unique_article[ $group ], $unique );
		} else {
			$this->unique_article[ $group ][] = $unique;
		}
	}

	/**
	 * @param $group
	 * @return array
	 */
	public function get_unique_article( $group ) {
		if ( isset( $this->unique_article[ $group ] ) ) {
			return $this->unique_article[ $group ];
		}

		return [];
	}
}
